// --- version 1 ----

class IdleGame{}

class GameLevel{}

/* abstract ??? */ 
class Monster{}

class LargeMonster extends Monster {}
class FurryMonster extends Monster {}
class InvisibleMonster extends Monster {}

// ****************** main program ******************

let g = new IdleGame();
console.log(g);
/* NOT YET WORKING ....
while (g.isRunning()){
	g.oneTurn();
	console.log(g);
}
*/