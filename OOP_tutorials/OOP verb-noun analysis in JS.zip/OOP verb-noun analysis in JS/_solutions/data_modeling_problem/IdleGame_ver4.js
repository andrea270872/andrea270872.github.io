class IdleGame{
	constructor() {
		this._level = new GameLevel();
		this._level.start();
	}

	oneTurn(){
		this._level.hitAllMonsters();
	}

	isRunning(){
		return !this._level.allMonstersPassedOut();
	}

	toString(){
		return this._level.toString();
	}
}

class GameLevel{
	constructor() {
		this._monsters = [];
	}

	start(){
		this._monsters = [];
		this._monsters.push( new LargeMonster() );
		this._monsters.push( new LargeMonster() );
		this._monsters.push( new FurryMonster() );
		this._monsters.push( new FurryMonster() );
		this._monsters.push( new InvisibleMonster() );
		this._monsters.push( new InvisibleMonster() );
	}

	toString(){
		return this._monsters.join(' / ');
	}

	allMonstersPassedOut(){
		let allPassedOut = true; // assume they all have passed out!
		for (let m of this._monsters){
			if (!m.hasPassedOut()){
				allPassedOut = false; // realize: at least 1 is still awake!
				break;
			}
		}
		return allPassedOut;
	}

	hitAllMonsters(){
		for (let m of this._monsters){
			if (!m.hasPassedOut()){ // only hitting monsters who are awake!
				let damage = Math.floor(Math.random()*6+1); // roll 1 dice
				m.hit(damage);
			}
		}
	}

}

/* abstract ??? */ 
class Monster{
	constructor(){
		this._hp = 80; // initial HP value
	}

	// default behavior for any monster
	hit(damagePoints){
		this._hp -= damagePoints;
	}

	hasPassedOut(){
		if (this._hp<=0)
			return true;
		return false;
	}

	toString(){
		let text = `M:${this._hp}`;
		if (this.hasPassedOut())
			text = ' x_x';
		return text;
	}
}

class LargeMonster extends Monster {
	hit(damagePoints){
		this._hp -= Math.floor(damagePoints/2);
	}

	toString(){
		return 'Lrg' + super.toString(); // calling the toString of the super-class
	}	
}
class FurryMonster extends Monster {
	toString(){
		return 'Flf' + super.toString(); // calling the toString of the super-class
	}
}
class InvisibleMonster extends Monster {
	hit(damagePoints){
		this._hp -= 1;
	}

	toString(){
		return 'Inv' + super.toString(); // calling the toString of the super-class
	}
}

// ****************** main program ******************
let fs = require('fs');
let fileName = __dirname + '/monsters_story.txt';
fs.writeFileSync(fileName, '**** Monsters Story ****\n\n'); 

let g = new IdleGame();
let currentTurn = 0;
console.log(currentTurn +' -> '+ g.toString());
fs.appendFileSync(fileName, currentTurn +' -> '+ g.toString() +'\n'); 
while (g.isRunning()){
	currentTurn++;
	g.oneTurn();
	console.log(currentTurn +' -> '+ g.toString());
	fs.appendFileSync(fileName, currentTurn +' -> '+ g.toString() +'\n'); 
}

fs.appendFileSync(fileName, '\n\n**** the end ****'); 