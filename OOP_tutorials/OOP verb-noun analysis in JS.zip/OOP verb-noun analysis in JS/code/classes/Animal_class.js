// use this file together with classes_example3.js 
// -----------------------------------------------

class Animal { 
  constructor(name) {
    this.name = name;
  }
  
  toString() {
    return `Animal ${this.name}.`;
  }
}


class Mammal extends Animal {
  constructor(name) {
    super(name); // call the super class constructor and pass in the name parameter
  }
}


class Dog extends Mammal {
  constructor(name) {
    super(name); // same as the constructor for Mammal ;)
  }

  toString() {
    return `The dog ${this.name} barks.`;
  }
}


class Human extends Mammal {
  constructor(name) {
    super(name); // same as the constructor for Mammal ;)
    this.owned = [];
  }

  toString() {
  	let text='';
    text += `The human ${this.name} talks.`;
    if (this.owned.length>0){
    	text += `\n    And owns these animals: ${ this.owned.map( a=>a.name ) }.`;
    }
    return text;
  }

  addOwnedAnimal(someAnimal){
  	this.owned.push(someAnimal);
  }

}


// declare what you want to export
module.exports = {
  'Animal': Animal,
  'Mammal': Mammal,
  'Dog': Dog,  
  'Human': Human
};