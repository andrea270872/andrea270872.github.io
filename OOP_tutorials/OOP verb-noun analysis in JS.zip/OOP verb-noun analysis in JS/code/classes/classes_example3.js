// import all classes from external file
classes = require('./Animal_class.js');
let Animal = classes['Animal'];
let Dog = classes['Dog'];
let Human = classes['Human'];

// *** main program ***
let d = new Dog('Mitzie');
console.log( d );
console.log( d.toString() ); // The dog Mitzie barks.

let f = new Dog('Fuffy');

let me = new Human('Andrea');
console.log( me.toString() );
me.addOwnedAnimal( d );
me.addOwnedAnimal( f );
console.log( me.toString() );
