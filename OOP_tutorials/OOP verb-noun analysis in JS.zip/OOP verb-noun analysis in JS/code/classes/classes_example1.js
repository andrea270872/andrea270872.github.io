// FROM https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Classes
class Animal { 
  constructor(name) {
    this.name = name;
  }
  
  toString() {
    return `Animal ${this.name}.`;
  }
}


class Mammal extends Animal {
  constructor(name) {
    super(name); // call the super class constructor and pass in the name parameter
  }
}


class Dog extends Mammal {
  constructor(name) {
    super(name); // same as the constructor for Mammal ;)
  }

  toString() {
    return `The dog ${this.name} barks.`;
  }
}


// *** main program ***
let d = new Dog('Mitzie');
console.log( d );
console.log( d.toString() ); // The dog Mitzie barks.

// Check which class an object belongs to ...
console.log( d.constructor === Dog ); // -> true
console.log( d.constructor === Mammal ); // -> false

// Assert that something must be so!
console.assert( d.constructor === Dog , 'How can that be?! There is an error here!' );
// console.assert( d.constructor === Mammal , 'Sure... but it\'s wrong!' ); // -> error!