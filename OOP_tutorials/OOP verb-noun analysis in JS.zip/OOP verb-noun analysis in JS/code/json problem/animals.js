class Animal { 
  constructor(name) {
    this.name = name;
  }
  
  toString() {
    return `Animal ${this.name}.`;
  }
}


class Mammal extends Animal {
  constructor(name) {
    super(name); // call the super class constructor and pass in the name parameter
  }
}


class Dog extends Mammal {
  constructor(name) {
    super(name); // same as the constructor for Mammal ;)
  }

  toString() {
    return `The dog ${this.name} barks.`;
  }
}


class Human extends Mammal {
  constructor(name) {
    super(name); // same as the constructor for Mammal ;)
    this.owned = [];
  }

  toString() {
  	let text='';
    text += `The human ${this.name} talks.`;
    if (this.owned.length>0){
    	text += `\n    And owns these animals: ${ this.owned.map( a=>a.name ) }.`;
    }
    return text;
  }

  addOwnedAnimal(someAnimal){
  	this.owned.push(someAnimal);
  }

}


// *** main program ***
let d = new Dog('Mitzie');
console.log( d );
console.log( d.toString() ); // The dog Mitzie barks.

let f = new Dog('Fuffy');

let me = new Human('Andrea');
console.log( me.toString() );
me.addOwnedAnimal( d );
me.addOwnedAnimal( f );
console.log( me.toString() );


// --- JSON and classes ---
console.log('\n\n\n\n\n');
console.log( '<<me>> as an object: ' );
console.dir( me ); // I can see the type information! E.g. me is a Human object, not just Object.

let a = JSON.stringify(me);
console.log( '<<me>> as a string: ' );
console.dir( a );
let meClone = JSON.parse(a); // ... but all methods are gone, and the type/class info is lost! :( :( 
console.log( '<<meClone>> as an object: ' );
console.dir( meClone );

let humanMe = new Human();
Object.assign(humanMe, meClone ); // in this way humanMe should have all types in the right places!
console.log( '<<humanMe>> as an object: ' );
console.dir( humanMe );

console.log('\n--- testing ---');
console.log('What type is <<me>>? ' + me.constructor.name);
console.log('What type is <<me.owned[0]>>? ' + me.owned[0].constructor.name);
console.log('What type is <<meClone>>? ' + meClone.constructor.name);
console.log('What type is <<meClone.owned[0]>>? ' + meClone.owned[0].constructor.name);
console.log('What type is <<humanMe>>? ' + humanMe.constructor.name);                   // fixed!
console.log('What type is <<humanMe.owned[0]>>? ' + humanMe.owned[0].constructor.name); // not fixed :(



// see: https://thecodebarbarian.com/object-assign-vs-object-spread.html