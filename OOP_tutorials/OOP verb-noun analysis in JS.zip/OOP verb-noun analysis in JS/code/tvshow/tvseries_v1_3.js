// and finally the toString methods, etc...

class TvShow { 
  constructor(name) {
    this.name = name;
    this._seasons = [];
  }

  addSeason(s){
    console.assert( s.constructor === Season , 's must be a Season object' );
    this._seasons.push(s);
  }

  describe(){
    return `The TvShow "${this.name}".`;
  }

  calculateTotal(){
    let total = new Time(0,0,0);
    this._seasons.forEach(s => total=total.add(s.calculateSeasonTotal()) );
    return total;
  }

  toString(){
    // PRINT ALSO ALL THE SEASONS
    return this.describe()+`
${this._seasons.join('\n')}`;
  }
}

class Time { 
  constructor(days,hours,minutes) {
    this.d = days;
    this.h = hours;
    this.m = minutes;
    this._simplify();
  }

  add(t){
    console.assert( t.constructor === Time , 't must be a Time object' );
    let returnTime = new Time(this.d+t.d,
                              this.h+t.h,
                              this.m+t.m);
    returnTime._simplify();
    return returnTime;
  }

  // a private method
  // fixes the notation of a Time object: e.g. <0d,27h,65m> should be 
  //                                           <0d,28h,5m> and even better 
  //                                           <1d,4h,5m>
  _simplify(){
    if (this.m>60){
      let fixed = this.m % 60;
      let extra = Math.floor((this.m - fixed)/60);
      this.m = fixed;
      this.h += extra;
    }
    if (this.h>24){
      let fixed = this.h % 24;
      let extra = Math.floor((this.h - fixed)/24);
      this.h = fixed;
      this.d += extra;
    }
  }

  toString(){
    return `<${this.d}days ${this.h}:${this.m}>`;
  }

  // returns a boolean
  isEqual(t){
    console.assert( t.constructor === Time , 't must be a Time object' );

    // 1- bring both in "normal form"    
    this._simplify();
    t._simplify();

    // 2- now check that the 3 attributes are all the same
    return ( (this.d==t.d) && 
             (this.h==t.h) && 
             (this.m==t.m) );
  }

}

class Season { 
	constructor(sequenceNumber){
		this.seqNum = sequenceNumber;
    this._episodes = [];
	}

  describe(){
    return `Series #${this.seqNum}.`;
  }

  addEpisode(e){
    console.assert( (e.constructor === Episode) || 
                    (e.constructor === Pilot) , 'e must be an Episode or Pilot object' );
    this._episodes.push(e);
  }  

  calculateSeasonTotal(){
    let total = new Time(0,0,0);
    this._episodes.forEach(e => total=total.add(e.duration) );
    return total;
  }

  toString(){
    return this.describe()+`
   ${this._episodes.join('\n   ')}`;
  }  
}

class Episode { 
  constructor(name,duration,sequenceNumber) {
  	console.assert( name.constructor === String , 'name must be a string' );
  	console.assert( duration.constructor === Time , 'duration must be a Time object' );  	
  	console.assert( sequenceNumber.constructor === Number , 'sequenceNumber must be a number' );
    this.name = name; 
    this.duration = duration;
    this.seqNum = sequenceNumber;
  }	

  describe(){
    return `Episode #${this.seqNum} - ${this.name} [${this.duration}].`;
  }  

  toString(){
    return this.describe();
  }  
}

class Pilot extends Episode{ 
  constructor(name,duration,sequenceNumber) {
    super(name,duration,sequenceNumber);
  }

  describe(){
    return `Pilot - ${this.name} [${this.duration}].`;
  }  

  // no need to add a toString here... it will work via the super-class method!
}

// --- the "main" part of the program ---
// Just for testing ...
let show = new TvShow('The Banana Splits');
let season1 = new Season(1);
let p = new Pilot('The pilot',new Time(0,0,59),0);
let episode1 = new Episode('Episode 1',new Time(0,1,0), 1);
let episode2 = new Episode('Episode 2',new Time(0,0,58), 2);

show.addSeason(season1);
season1.addEpisode(p);
season1.addEpisode(episode1);
season1.addEpisode(episode2);

show.addSeason( new Season(2) );
show.addSeason( new Season(3) );

console.log( ''+show );
/*
console.log( ''+season1 );
console.log( ''+p  );
console.log( ''+episode1 );
console.log( ''+episode2 );
*/

// durations ------------------------------------
console.log( 'pilot.duration =' , ''+p.duration );
console.log( 'episode1.duration =' , ''+episode1.duration );
console.log( 'episode2.duration =', ''+episode2.duration );
console.log( 'season 1 duration = ' , ''+season1.calculateSeasonTotal() ); // -> 2h 57m
console.log( 'show duration = ' , ''+show.calculateTotal() ); // -> 2h 57m


// --- testing the isEqual method of class Time ---
let t1 = new Time(0,27,65);
console.log( ''+t1 ); // -> 1d,4h,5m 
let t2 = new Time(7,1,70);
console.log( ''+t2 ); // -> 7d,2h,10m 

console.log( t1.isEqual(t2) ); // -> false
console.log( t1.isEqual(t1) ); // -> true
console.log( t1.isEqual( new Time(1,4,0).add(new Time(0,0,5)) ) ); // -> true
