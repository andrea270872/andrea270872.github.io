// then the constructors and the attributes

class TvShow { 
  constructor(name) {
    this.name = name;
  }
}

class Time { 
  constructor(days,hours,minutes) {
    this.d = days;
    this.h = hours;
    this.m = minutes;
  }
}

class Season { 
  constructor(sequenceNumber){
    this.seqNum = sequenceNumber;
  }
}

class Episode { 
  constructor(name,duration,sequenceNumber) {
    console.assert( name.constructor === String , 'name must be a string' );
    console.assert( duration.constructor === Time , 'duration must be a Time object' );   
    console.assert( sequenceNumber.constructor === Number , 'sequenceNumber must be a number' );
    this.name = name; 
    this.duration = duration;
    this.seqNum = sequenceNumber;
  } 
}

class Pilot extends Episode{ 
  constructor(name,duration,sequenceNumber) {
    super(name,duration,sequenceNumber);
  }
}

// --- the "main" part of the program ---
// Just for testing ...
let show = new TvShow('The Banana Splits');
let season1 = new Season(1);
let p = new Pilot('The pilot',new Time(0,0,59),0);
let episode1 = new Episode('Episode 1',new Time(0,1,0), 1);
let episode2 = new Episode('Episode 2',new Time(0,0,58), 2);
console.log( show );
console.log( season1 );
console.log( p );
console.log( episode1 );
console.log( episode2 );