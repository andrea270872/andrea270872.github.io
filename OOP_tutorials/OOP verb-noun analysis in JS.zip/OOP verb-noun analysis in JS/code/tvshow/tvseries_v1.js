// first: the classes

class TvShow { 
}

class Time { 
}

class Season { 
}

class Episode { 
}

class Pilot extends Episode { 
}

// --- the "main" part of the program ---
// to do