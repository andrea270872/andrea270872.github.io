// and finally the toString methods, etc...

// and finally the toString methods, etc...

class TvShow { 
  constructor(name) {
    this.name = name;
    this._seasons = [];
  }

  addSeason(s){
    console.assert( s.constructor === Season , 's must be a Season object' );
    this._seasons.push(s);
  }

  describe(){
    return `The TvShow "${this.name}".`;
  }

  calculateTotal(){
    let total = new Time(0,0,0);
    this._seasons.forEach(s => total=total.add(s.calculateSeasonTotal()) );
    return total;
  }

  toString(){
    // PRINT ALSO ALL THE SEASONS
    return this.describe()+`
${this._seasons.join('\n')}`;
  }
}

class Time { 
  constructor(days,hours,minutes) {
    this.d = days;
    this.h = hours;
    this.m = minutes;
    this._simplify();
  }

  add(t){
    console.assert( t.constructor === Time , 't must be a Time object' );
    let returnTime = new Time(this.d+t.d,
                              this.h+t.h,
                              this.m+t.m);
    returnTime._simplify();
    return returnTime;
  }

  // a private method
  // fixes the notation of a Time object: e.g. <0d,27h,65m> should be 
  //                                           <0d,28h,5m> and even better 
  //                                           <1d,4h,5m>
  _simplify(){
    if (this.m>60){
      let fixed = this.m % 60;
      let extra = Math.floor((this.m - fixed)/60);
      this.m = fixed;
      this.h += extra;
    }
    if (this.h>24){
      let fixed = this.h % 24;
      let extra = Math.floor((this.h - fixed)/24);
      this.h = fixed;
      this.d += extra;
    }
  }

  toString(){
    return `<${this.d}days ${this.h}:${this.m}>`;
  }

  // returns a boolean
  isEqual(t){
    console.assert( t.constructor === Time , 't must be a Time object' );

    // 1- bring both in "normal form"    
    this._simplify();
    t._simplify();

    // 2- now check that the 3 attributes are all the same
    return ( (this.d==t.d) && 
             (this.h==t.h) && 
             (this.m==t.m) );
  }

}

class Season { 
	constructor(sequenceNumber){
		this.seqNum = sequenceNumber;
    this._episodes = [];
	}

  describe(){
    return `Series #${this.seqNum}.`;
  }

  addEpisode(e){
    console.assert( (e.constructor === Episode) || 
                    (e.constructor === Pilot) , 'e must be an Episode or Pilot object' );
    this._episodes.push(e);
  }  

  calculateSeasonTotal(){
    let total = new Time(0,0,0);
    this._episodes.forEach(e => total=total.add(e.duration) );
    return total;
  }

  toString(){
    return this.describe()+`
   ${this._episodes.join('\n   ')}`;
  }  
}

class Episode { 
  constructor(name,duration,sequenceNumber) {
  	console.assert( name.constructor === String , 'name must be a string' );
  	console.assert( duration.constructor === Time , 'duration must be a Time object' );  	
  	console.assert( sequenceNumber.constructor === Number , 'sequenceNumber must be a number' );
    this.name = name; 
    this.duration = duration;
    this.seqNum = sequenceNumber;
  }	

  describe(){
    return `Episode #${this.seqNum} - ${this.name} [${this.duration}].`;
  }  

  toString(){
    return this.describe();
  }  
}

class Pilot extends Episode{ 
  constructor(name,duration,sequenceNumber) {
    super(name,duration,sequenceNumber);
  }

  describe(){
    return `Pilot - ${this.name} [${this.duration}].`;
  }  

  // no need to add a toString here... it will work via the super-class method!
}

// --------------------------------------------------------
// --- Main                                             ---
// --------------------------------------------------------

// 1- declare some things about a certain TVShow: "populate" a data structure
let show1 = new TvShow("Star Trek");
	let s1 = new Season(1);
		let ep1 = new Episode("The Man Trap",new Time(0,0,50),1);
		let p = new Pilot("The cage",new Time(0,1,5),0);
		let p2 = new Pilot("Where No Man Has Gone Before",new Time(0,1,0),0);
		s1.addEpisode(p);
		s1.addEpisode(p2);
		s1.addEpisode(ep1);
		for (let i=2;i<=29;i++){
			s1.addEpisode( new Episode(	`Episode ${i}`,new Time(0,0,50),i) );
		}
	// DEBUG console.log('season:' + s1);
	show1.addSeason( s1 );
// ... etc. ...

// 2- use the knowledge "in" the classes to perform some calculation
console.log(''+show1);
console.log("total time="+ show1.calculateTotal() );

// get more data here: https://en.wikipedia.org/wiki/List_of_Star_Trek:_The_Original_Series_episodes