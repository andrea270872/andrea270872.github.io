// --------------------------------------------------------
// --- here is how I would like to use the TVShow class ---
// --------------------------------------------------------

// 1- declare some things about a certain TVShow: "populate" a data structure
let show1 = new TvShow("Star Trek");
	let s1 = new Season(1);
		let ep1 = new Episode("The first episode",1,new Time(0,0,50));
		let p = new Pilot("The cage",new Time(0,1,5));
		s1.add(p);
		s1.add(ep1);
		s1.add( new Episode("The second episode",2,new Time(0,0,50)) );
	console.log('season:' + s1);
	show1.add( s1 );
// ... etc. ...

// 2- use the knowledge "in" the classes to perform some calculation
console.log("the show:\n" + show1);
console.log("total time="+ show1.caculateTotalTime() );

//////////////////////////////////////////////////////////////////
// NOTE: this code cannot work, because we don't have the classes 
//       needed, like TvShow, etc. 
//////////////////////////////////////////////////////////////////
