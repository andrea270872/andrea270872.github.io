class Animal:
  def __init__(self,name):
    self.name = name
  
  def __str__(self):
    return f"Animal {self.name}."


class Mammal(Animal):
  def __init__(self,name):
    super().__init__(name) # call the super class constructor and pass in the name parameter


class Dog(Mammal):
  def __init__(self,name):
    super().__init__(name) # same as the constructor for Mammal ;)

  def __str__(self):
    return f"The dog {self.name} barks."


class Human(Mammal):
  def __init__(self,name):
    super().__init__(name) # same as the constructor for Mammal ;)
    self.owned = []

  def __str__(self):
    text = f"The human {self.name} talks."
    
    if len(self.owned)>0:
      name_list = list( map(lambda a: a.name, self.owned ) )
      text += f"\n    And owns these animals: { ",".join(name_list) }."

    return text


  def addOwnedAnimal(self,someAnimal):
  	self.owned.append(someAnimal)






# *** main program ***
d = Dog('Mitzie')
print( d ) # The dog Mitzie barks.

# Check which class an object belongs to ...
##print( isinstance(d,Dog) )    # -> true
##print( isinstance(d,Mammal) ) # -> false


f = Dog('Fuffy')
me = Human('Andrea')
print( me )
me.addOwnedAnimal( d )
me.addOwnedAnimal( f )
print( me ) # now I have a dog!


