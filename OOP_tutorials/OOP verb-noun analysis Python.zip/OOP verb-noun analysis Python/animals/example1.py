class Animal:
  def __init__(self,name):
    self.name = name
  
  def __str__(self):
    return f"Animal {self.name}."


class Mammal(Animal):
  def __init__(self,name):
    super().__init__(name) # call the super class constructor and pass in the name parameter


class Dog(Mammal):
  def __init__(self,name):
    super().__init__(name) # same as the constructor for Mammal ;)

  def __str__(self):
    return f"The dog {self.name} barks."




# *** main program ***
d = Dog('Mitzie')
print( d ) # The dog Mitzie barks.
# same as:   print( d.__str__() ) 

# Check which class an object belongs to ...
print( isinstance(d,Dog) )    # -> true
print( isinstance(d,Mammal) ) # -> false
