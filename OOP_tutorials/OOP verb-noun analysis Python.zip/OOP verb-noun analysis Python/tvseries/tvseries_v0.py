# --------------------------------------------------------
# --- here is how I would like to use the TVShow class ---
# --------------------------------------------------------

# 1- declare some things about a certain TVShow: "populate" a data structure
show = TvShow('The Banana Splits')
season1 = Season(1)
p = Pilot('The pilot', Time(0,0,59),0)

episode1 = Episode('Episode 1',Time(0,1,0), 1)
episode2 = Episode('Episode 2',Time(0,0,58), 2)

show.addSeason(season1);
season1.addEpisode(p);
season1.addEpisode(episode1);
season1.addEpisode(episode2);

# 2- use the knowledge "in" the classes to perform some calculation
print("the show: " + show);
print("total time = "+ show.calculateTotal() )

######################################################################
## NOTE: this code cannot work, because we don't have the classes 
##       needed, like TvShow, etc. 
######################################################################
