# then the constructors and the attributes

class TvShow:
  def __init__(self,name):
    self.name = name

# it could also be: def __str__(self):  .....
  def describe(self):
    return f"The TvShow '{self.name}'"

  def __str__(self):
    return self.describe()


class Time:
  def __init__(self,days,hours,minutes):
    self.d = days
    self.h = hours
    self.m = minutes

  def describe(self):
    return f"<{self.d}days {self.h}:{self.m}>"
  
  def __str__(self):
    return self.describe()


class Season:
  def __init__(self,sequenceNumber):
    self.seqNum = sequenceNumber

  def describe(self):
    return f"Season #{self.seqNum}."

  def __str__(self):
    return self.describe()



class Episode:
  """
    name             must be a string
    duration         must be a Time object
    sequenceNumber   must be a number
  """

  def __init__(self,name,duration,sequenceNumber):
    self.name = name
    self.duration = duration
    self.seqNum = sequenceNumber

  def describe(self):
    return f"Episode #{self.seqNum} - {self.name} [{self.duration}]."

  def __str__(self):
    return self.describe()



class Pilot(Episode):
  def __init__(self,name,duration,sequenceNumber):
    super().__init__(name,duration,sequenceNumber)

  def describe(self):
    return f"Pilot - {self.name} [{self.duration}]."

  def __str__(self):
    return self.describe()


# --- the "main" part of the program ---
# Just for testing ...
show = TvShow('The Banana Splits')
season1 = Season(1)
p = Pilot('The pilot', Time(0,0,59),0)

episode1 = Episode('Episode 1',Time(0,1,0), 1)
episode2 = Episode('Episode 2',Time(0,0,58), 2)

print( show )
print( season1 )
print( p )
print( episode1 )
print( episode2 )
