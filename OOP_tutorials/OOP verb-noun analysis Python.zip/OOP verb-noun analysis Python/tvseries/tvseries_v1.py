# first: the classes

class TvShow:
	pass


class Time:
	pass

class Season:
	pass

class Episode:
	pass

class Pilot(Episode):
	pass

# --- the "main" part of the program ---
#### to dos