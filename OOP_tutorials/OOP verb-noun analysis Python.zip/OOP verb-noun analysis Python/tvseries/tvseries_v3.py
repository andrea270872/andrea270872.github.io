# then the constructors and the attributes

import math

class TvShow:
  def __init__(self,name):
    self.name = name
    self.__seasons = []

  ################################
  # s  must be a Season object
  ################################
  def addSeason(self,s):
    self.__seasons.append(s)

# it could also be: def __str__(self):  .....
  def describe(self):
    return f"The TvShow '{self.name}'"

  def __str__(self):
    return self.describe()

  def calculateTotal(self):
    total = Time(0,0,0)
    for season in self.__seasons:
      total = total.add( season.calculateSeasonTotal() ) 
    return total


class Time:
  def __init__(self,days,hours,minutes):
    self.d = days
    self.h = hours
    self.m = minutes
    self.__simplify()

  def describe(self):
    return f"<{self.d}days {self.h}:{self.m}>"
  
  def __str__(self):
    return self.describe()

  ### t   must be a Time object
  def add(self,t):
    returnTime = Time(self.d+t.d,
                      self.h+t.h,
                      self.m+t.m)
    returnTime.__simplify()
    return returnTime

  ## a private method
  ## fixes the notation of a Time object: e.g. <0d,27h,65m> should be 
  ##                                           <0d,28h,5m> and even better 
  ##                                           <1d,4h,5m>
  def __simplify(self):
    if self.m>60:
      fixed = self.m % 60
      extra = math.floor((self.m - fixed)/60)
      self.m = fixed
      self.h += extra
    
    if self.h>24:
      fixed = self.h % 24
      extra = math.floor((self.h - fixed)/24)
      self.h = fixed
      self.d += extra


class Season:
  def __init__(self,sequenceNumber):
    self.seqNum = sequenceNumber
    self.__episodes = []

  ## e must be an Episode or a Pilot object
  def addEpisode(self,e):
    self.__episodes.append(e)
  
  def describe(self):
    return f"Season #{self.seqNum}."

  def __str__(self):
    return self.describe()

  def calculateSeasonTotal(self):
    total = Time(0,0,0)
    for ep in self.__episodes:
      total=total.add( ep.duration )
    return total


class Episode:
  """
    name             must be a strings
    duration         must be a Time object
    sequenceNumber   must be a number
  """

  def __init__(self,name,duration,sequenceNumber):
    self.name = name
    self.duration = duration
    self.seqNum = sequenceNumber

  def describe(self):
    return f"Episode #{self.seqNum} - {self.name} [{self.duration}]."

  def __str__(self):
    return self.describe()



class Pilot(Episode):
  def __init__(self,name,duration,sequenceNumber):
    super().__init__(name,duration,sequenceNumber)

  def describe(self):
    return f"Pilot - {self.name} [{self.duration}]."

  def __str__(self):
    return self.describe()





# --- the "main" part of the program ---
# Just for testing ...

show = TvShow('The Banana Splits')
season1 = Season(1)
p = Pilot('The pilot', Time(0,0,59),0)

episode1 = Episode('Episode 1',Time(0,1,0), 1)
episode2 = Episode('Episode 2',Time(0,0,58), 2)

show.addSeason(season1);
season1.addEpisode(p);
season1.addEpisode(episode1);
season1.addEpisode(episode2);

print( show )
print( season1 )
print( p )
print( episode1 )
print( episode2 )



# test Time objects ---------------------------
t1 = Time(0,27,65)
print( t1 ) # -> 1d,4h,5m 
t2 = Time(7,1,70)
print( t2 ) # -> 7d,2h,10m 
t3 = t1.add(t2)
print( t3 ) # -> 8d,6h,15m 

# durations ------------------------------------
print( 'pilot.duration =' , p.duration )
print( 'episode1.duration =' , episode1.duration )
print( 'episode2.duration =', episode2.duration )
print( 'season 1 duration = ' , season1.calculateSeasonTotal() ) ### -> 2h 57m
print( 'show duration = ' , show.calculateTotal() ) ### -> 2h 57m