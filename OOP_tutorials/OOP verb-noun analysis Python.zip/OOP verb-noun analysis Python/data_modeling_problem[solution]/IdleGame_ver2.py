import math
import random

class Idle_game:
	def __init__(self):
		self.__level = Game_level()
		self.__level.start()

	def one_turn(self):
		self.__level.hit_all_monsters()

	def is_running(self):
		return not self.__level.all_monsters_passed_out()

	def __str__(self):
		return self.__level.__str__()

class Game_level:
	def __init__(self):
		self.__monsters = []

	def start(self):
		self.__monsters = []
		self.__monsters.append( Large_monster() )
		self.__monsters.append( Large_monster() )
		self.__monsters.append( Furry_monster() )
		self.__monsters.append( Furry_monster() )
		self.__monsters.append( Invisible_monster() )
		self.__monsters.append( Invisible_monster() )

	def __str__(self):
		return ' / '.join( map(lambda m: m.__str__(), self.__monsters ) )
	

	def all_monsters_passed_out(self):
		all_passed_out = True # assume they all have passed out!
		for m in self.__monsters:
			if not m.has_passed_out():
				all_passed_out = False # realize: at least 1 is still awake!
				break
		return all_passed_out

	def hit_all_monsters(self):
		for m in self.__monsters:
			if not m.has_passed_out(): # only hitting monsters who are awake!
				damage = random.randint(1,6); # roll 1 dice
				m.hit(damage)

# abstract ???
class Monster:
	def __init__(self):
		self._hp = 80 # initial HP value

	# default behavior for any monster
	def hit(self,damagePoints):
		self._hp -= damagePoints

	def has_passed_out(self):
		if self._hp<=0:
			return True
		return False

	def __str__(self):
		return f"M:{self._hp}"


class Large_monster(Monster):
	pass

class Furry_monster(Monster):
	pass

class Invisible_monster(Monster):
	pass


# ****************** main program ******************
g = Idle_game()
currentTurn = 0
print(currentTurn , ' -> ' , g )
while g.is_running():
	currentTurn+=1
	g.one_turn()
	print(currentTurn , ' -> ' , g )
