# --- version 1 ----

class Idle_game:
	pass

class Game_level:
	pass

# abstract ???
class Monster:
	pass

class Large_monster(Monster):
	pass
	
class Furry_monster(Monster):
	pass

class Invisible_monster(Monster):
	pass

# ****************** main program ******************

g = Idle_game()
print(g)
""" 
# NOT YET WORKING ....
while g.isRunning():
	g.oneTurn()
	print(g)
"""